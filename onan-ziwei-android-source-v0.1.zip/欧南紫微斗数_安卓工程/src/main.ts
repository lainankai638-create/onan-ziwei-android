/**
 * 欧南·紫微斗数 —— 离线安卓前端。
 * 真实排盘调用 Renhuai123/ziwei-doushu (MIT) 的 generateChart，非自制假盘。
 * 原版源代码由 scripts/fetch-engine.sh 下载，Vite 将算法和所需依赖编入 APK 资源。
 */
import './style.css';
import { generateChart, setBrightnessSchool } from '../vendor/ziwei-doushu/lib/ziwei/algorithm';
import { calculateTrueSolarTime, resolveZiweiDayOffset, shiftGregorianDate, formatTrueSolarClock, isValidGregorianDate } from '../vendor/ziwei-doushu/lib/ziwei/true-solar-time';
import { STEMS, BRANCHES, SI_HUA_TABLE } from '../vendor/ziwei-doushu/lib/ziwei/constants';
import type { ZiweiChart, Palace, SiHua, BirthInfo } from '../vendor/ziwei-doushu/lib/ziwei/types';

interface BirthForm {
  name: string; date: string; time: string;
  gender: 'male' | 'female';
  longitude: string; utcOffset: string;
  leap: 'split' | 'next-month' | 'prev-month' | 'origin-month';
  late: 'next-day' | 'current-day';
  dst: boolean;
  annualYear: number;
}
interface HistoryItem { id: string; storedAt: number; form: BirthForm }
const STORE_KEY = 'onan-ziwei-history-v1';
const GRID_BRANCH_ORDER = [5, 6, 7, 8, 4, 9, 3, 10, 2, 1, 0, 11];
const PALACE_GRID_STYLE: Record<number, string> = {
  5:'grid-row:1;grid-column:1', 6:'grid-row:1;grid-column:2',
  7:'grid-row:1;grid-column:3', 8:'grid-row:1;grid-column:4',
  4:'grid-row:2;grid-column:1', 9:'grid-row:2;grid-column:4',
  3:'grid-row:3;grid-column:1', 10:'grid-row:3;grid-column:4',
  2:'grid-row:4;grid-column:1', 1:'grid-row:4;grid-column:2',
  0:'grid-row:4;grid-column:3', 11:'grid-row:4;grid-column:4'
};
const app = document.querySelector<HTMLDivElement>('#app')!;
let activeChart: ZiweiChart | null = null;
let activeForm: BirthForm | null = null;
let selectedBranch = 0;
let chartNote = '';
let history = readHistory();

function escapeHtml(value: unknown): string {
  return String(value ?? '').replace(/[&<>"']/g, x => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x] || x));
}
function readHistory(): HistoryItem[] {
  try {
    const input = JSON.parse(localStorage.getItem(STORE_KEY) || '[]');
    return Array.isArray(input) ? input.filter(v => v && typeof v.id === 'string' && v.form && typeof v.form.date === 'string').slice(0, 200) : [];
  } catch { return []; }
}
function writeHistory(): boolean {
  try { localStorage.setItem(STORE_KEY, JSON.stringify(history)); return true; }
  catch { showMessage('手机存储不可用，无法保存。可以尝试清理空间或导出已有记录。', true); return false; }
}
function showMessage(msg: string, error = false): void {
  const el = document.querySelector<HTMLElement>('#message');
  if (!el) return;
  el.textContent = msg;
  el.className = error ? 'message is-error' : 'message';
}
function getSiHuaByStem(index: number): Record<SiHua, string> {
  const row = SI_HUA_TABLE[index];
  return { 禄: row?.[0] || '', 权: row?.[1] || '', 科: row?.[2] || '', 忌: row?.[3] || '' };
}
function renderFour(transforms: Record<SiHua,string>, prefix: string): string {
  return (['禄','权','科','忌'] as SiHua[])
    .map(k => `<span class="four-item"><b class="si si-${k}">${prefix}${k}</b>${escapeHtml(transforms[k] || '—')}</span>`).join('');
}

function readForm(): BirthForm {
  const form = document.querySelector<HTMLFormElement>('#birth-form')!;
  const f = new FormData(form);
  const g = String(f.get('gender'));
  const leap = String(f.get('leap'));
  const late = String(f.get('late'));
  const annualYear = Number(f.get('annualYear'));
  return {
    name: String(f.get('name') || '').trim().slice(0, 40),
    date: String(f.get('date') || ''), time: String(f.get('time') || ''),
    gender: g === 'female' ? 'female' : 'male',
    longitude: String(f.get('longitude') || '').trim(),
    utcOffset: String(f.get('utcOffset') || '480'),
    leap: (['split','next-month','prev-month','origin-month'].includes(leap) ? leap : 'split') as BirthForm['leap'],
    late: late === 'current-day' ? 'current-day' : 'next-day',
    dst: f.get('dst') === 'on',
    annualYear: annualYear >= 1900 && annualYear <= 2100 ? annualYear : new Date().getFullYear()
  };
}
function fillForm(data: BirthForm): void {
  const form = document.querySelector<HTMLFormElement>('#birth-form')!;
  for (const name of ['name','date','time','longitude','utcOffset','gender','leap','late','annualYear'] as const) {
    const el = form.elements.namedItem(name) as HTMLInputElement | HTMLSelectElement | null;
    if (el) el.value = String(data[name]);
  }
  (form.elements.namedItem('dst') as HTMLInputElement).checked = !!data.dst;
}
function compute(form: BirthForm): { chart: ZiweiChart; note: string } {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(form.date);
  const t = /^(\d{2}):(\d{2})$/.exec(form.time);
  if (!m || !t) throw new Error('请选择完整的公历出生日期和出生时间。');
  let [year, month, day] = [Number(m[1]), Number(m[2]), Number(m[3])];
  let [clockHour, clockMinute] = [Number(t[1]), Number(t[2])];
  if (!isValidGregorianDate(year, month, day) || year < 1900 || year > 2100) throw new Error('请选择 1900—2100 年间存在的公历日期。');
  if (clockHour < 0 || clockHour > 23 || clockMinute < 0 || clockMinute > 59) throw new Error('出生时间格式不正确。');
  let dstNote = '';
  if (form.dst) {
    const shifted = new Date(Date.UTC(year, month - 1, day, clockHour, clockMinute - 60));
    year = shifted.getUTCFullYear(); month = shifted.getUTCMonth() + 1;
    day = shifted.getUTCDate(); clockHour = shifted.getUTCHours(); clockMinute = shifted.getUTCMinutes();
    dstNote = '已按手动选择扣除 60 分钟夏令时。';
  }
  let longitude: number | undefined;
  if (form.longitude !== '') {
    longitude = Number(form.longitude);
    if (!Number.isFinite(longitude) || longitude < -180 || longitude > 180) throw new Error('出生地经度必须介于 -180 到 180。');
  }
  const utcOffsetMinutes = Number(form.utcOffset);
  if (!Number.isInteger(utcOffsetMinutes) || utcOffsetMinutes < -720 || utcOffsetMinutes > 840) throw new Error('时区偏移不正确。');
  const solar = calculateTrueSolarTime({ year, month, day, clockHour, clockMinute, longitude, utcOffsetMinutes });
  const dayOffset = resolveZiweiDayOffset(solar, form.late);
  const effective = shiftGregorianDate({year, month, day}, dayOffset);
  const birth: BirthInfo = {
    ...effective,
    hour: solar.branch,
    gender: form.gender,
    name: form.name || undefined,
    longitude,
    origInput: {
      year: Number(m[1]), month: Number(m[2]), day: Number(m[3]),
      clockHour: Number(t[1]), clockMinute: Number(t[2])
    }
  };
  // 原版默认亮度：斗数全书 QS 表（可留待后续添加流派切换）。
  setBrightnessSchool('default');
  const chart = generateChart(birth, { leapMonth: form.leap });
  const dateText = `${effective.year}-${String(effective.month).padStart(2,'0')}-${String(effective.day).padStart(2,'0')}`;
  const note = `${dstNote}排盘口径：${dateText} ${BRANCHES[solar.branch]}时；${longitude === undefined ? '未启用真太阳时' : '真太阳时 ' + formatTrueSolarClock(solar)}。${dayOffset ? '跨日 / 晚子时换日已处理。' : ''}`;
  return { chart, note };
}
function sectionHtml(): string {
  return `<header class="header">
    <div class="brand"><div class="brand-logo">紫</div><div><div class="overline">ONAN · OFFLINE CHART</div><h1>欧南·紫微斗数</h1><div class="brand-small">倪师《天纪》体系 · 传统术数文化研究</div></div></div>
    <div class="offline-pill"><span class="green-dot"></span> 本地排盘</div>
  </header>
  <div class="intro">命盘在设备内计算；不需要账号，不接入在线 AI 服务。输入的资料不会由本应用上传到服务器。</div>
  <section class="panel"><div class="section-head"><div><div class="eyebrow">01 / 出生信息</div><h2>起一张紫微命盘</h2></div><span class="subdued">公历日期 · 24 小时制</span></div>
  <form id="birth-form">
    <div class="form-grid">
      <label class="field field-full"><span>姓名 / 备注（选填）</span><input name="name" type="text" maxlength="40" placeholder="例如：自己的命盘" autocomplete="off"/></label>
      <label class="field"><span>出生公历日期</span><input name="date" type="date" min="1900-01-01" max="2100-12-31" value="1995-06-15" required/></label>
      <label class="field"><span>出生时间</span><input name="time" type="time" value="12:00" required/></label>
      <label class="field"><span>性别（传统排盘用途）</span><select name="gender"><option value="male">男</option><option value="female">女</option></select></label>
      <label class="field"><span>流年（公历）</span><input name="annualYear" type="number" min="1900" max="2100" value="${new Date().getFullYear()}" required /></label>
      <label class="field"><span>出生地经度（可选）</span><input name="longitude" type="number" step="0.0001" min="-180" max="180" placeholder="如 112.98（长沙）" /></label>
      <label class="field"><span>出生地标准时区</span><select name="utcOffset"><option value="480">中国标准时间 UTC+8</option><option value="540">UTC+9</option><option value="420">UTC+7</option><option value="0">UTC+0</option><option value="-300">UTC-5</option><option value="-480">UTC-8</option></select></label>
      <label class="field"><span>闰月算法</span><select name="leap"><option value="split">月中分界（原版默认）</option><option value="next-month">整月归下月</option><option value="prev-month">整月归本月</option><option value="origin-month">保留原闰月</option></select></label>
      <label class="field"><span>23:00—23:59 晚子时</span><select name="late"><option value="next-day">归次日（原版默认）</option><option value="current-day">归当日</option></select></label>
    </div>
    <label class="check-line"><input type="checkbox" name="dst"/> <span>手动减去 1 小时夏令时（仅在出生当时确实执行夏令时且时间未校正时勾选）</span></label>
    <p class="field-help">不填经度则按出生钟表时间确定时辰。真太阳时和闰月算法会影响临界时辰的排盘结果。</p>
    <div class="actions"><button type="submit" class="primary">生成命盘 <span>→</span></button><button id="save-button" class="secondary" type="button" disabled>保存到手机</button></div>
  </form>
  <div id="message" class="message" aria-live="polite"></div></section>
  <div id="chart-output"></div>
  <section class="panel history-panel"><div class="section-head"><div><div class="eyebrow">03 / 本地知识档案</div><h2>历史命盘</h2></div><span id="history-count" class="subdued"></span></div>
    <div class="history-actions"><button id="export-btn" class="secondary small">导出备份 JSON</button><button id="import-btn" class="secondary small">导入备份</button><input id="import-file" type="file" accept=".json,application/json" hidden /></div>
    <div id="history-list"></div><p class="field-help">历史记录只存在本机应用存储。清除应用数据或卸载可能丢失，请定期导出备份。</p>
  </section>
  <footer>排盘算法：Renhuai123 / ziwei-doushu（MIT）· iztro · lunar-javascript<br/>仅供传统文化学习研究，不是经过科学验证的人生预测工具。<br/>版本 v0.1 · 离线核心版</footer>`;
}
function renderChart(): void {
  const el = document.querySelector<HTMLElement>('#chart-output')!;
  if (!activeChart || !activeForm) { el.innerHTML = ''; return; }
  const chart = activeChart;
  const chartByBranch = new Map(chart.palaces.map(p => [p.branch,p]));
  if (!chartByBranch.has(selectedBranch)) selectedBranch = chart.mingGongBranch;
  const annualStem = ((activeForm.annualYear - 4) % 10 + 10) % 10;
  const annualMap = getSiHuaByStem(annualStem);
  const natalMap = getSiHuaByStem(chart.lunarInfo.yearStem);
  const palaceHtml = GRID_BRANCH_ORDER.map(branch => {
    const p = chartByBranch.get(branch);
    if (!p) return '';
    const stars = p.stars.filter(s=>s.type === 'major').slice(0,3);
    const secondary = p.stars.filter(s=>s.type==='lucky').slice(0,2);
    return `<button type="button" class="palace ${p.isMingGong?'is-ming':''} ${p.branch===selectedBranch?'is-selected':''}" style="${PALACE_GRID_STYLE[branch]}" data-palace="${branch}">
      <div class="palace-label"><span>${escapeHtml(p.name)}</span><span>${escapeHtml(STEMS[p.stem])}${escapeHtml(BRANCHES[p.branch])}</span></div>
      <div class="major-list">${stars.length ? stars.map(s=>`<span class="major">${escapeHtml(s.name)}${s.siHua?`<b class="mutagen">${escapeHtml(s.siHua)}</b>`:''}</span>`).join('') : '<span class="minor">无主星</span>'}</div>
      <div class="minor-list">${secondary.map(s=>escapeHtml(s.name)).join(' · ')}</div>
      <div class="palace-foot">${p.isMingGong?'命 ':''}${p.isShenGong?'身 ':''}${p.daXianAge?`${p.daXianAge[0]}-${p.daXianAge[1]}岁`:''}</div>
    </button>`;
  }).join('');
  const current = chartByBranch.get(selectedBranch) || chart.palaces[0];
  const detailGroups: {label:string; type:Palace['stars'][number]['type']}[] = [
    {label:'主星',type:'major'},{label:'吉星',type:'lucky'},
    {label:'煞星',type:'sha'},{label:'杂曜',type:'minor'}
  ];
  const detail = detailGroups.map(group=>{
    const stars=current.stars.filter(s=>s.type===group.type);
    if(!stars.length) return '';
    return `<div class="star-group"><div class="star-group-label">${group.label}</div><div class="star-chips">${stars.map(s=>`<span class="star-chip ${group.type}">${escapeHtml(s.name)}${s.brightnessRaw?` <small>${escapeHtml(s.brightnessRaw)}</small>`:''}${s.siHua?` <b class="si si-${s.siHua}">${s.siHua}</b>`:''}${Object.entries(annualMap).filter(([,name])=>name===s.name).map(([k])=>` <b class="si si-${k}">流${k}</b>`).join('')}</span>`).join('')}</div></div>`;
  }).join('');
  const dxHtml = chart.daXians.map((d,i)=>`<div class="daxian ${i===chart.currentDaXianIndex?'active':''}"><span>${d.startAge}—${d.endAge} 岁</span><b>${escapeHtml(d.palaceName)}</b><small>${escapeHtml(d.stemName||'')}</small></div>`).join('');
  el.innerHTML = `<section class="panel chart-panel"><div class="section-head"><div><div class="eyebrow">02 / 命盘</div><h2>${escapeHtml(activeForm.name || '新命盘')} · 十二宫</h2></div><span class="subdued">点击宫位查看星曜</span></div>
    <div class="chart-summary"><div class="summary-item"><small>农历</small><b>${chart.lunarInfo.lunarYear}年 ${chart.lunarInfo.isLeapMonth?'闰':''}${chart.lunarInfo.lunarMonth}月 ${chart.lunarInfo.lunarDay}日</b></div><div class="summary-item"><small>五行局</small><b>${escapeHtml(chart.wuxingJuName)}</b></div><div class="summary-item"><small>阴阳性别</small><b>${escapeHtml(chart.yinYangGender||'—')}</b></div><div class="summary-item"><small>命主 · 身主</small><b>${escapeHtml(chart.mingZhu||'—')} · ${escapeHtml(chart.shenZhu||'—')}</b></div></div>
    <div class="chart-note">${escapeHtml(chartNote)}</div>
    <div class="board-viewport"><div class="board">${palaceHtml}
      <div class="board-center"><div class="center-logo">紫微</div><div class="center-title">斗数命盘</div><div class="center-small">${escapeHtml(chart.wuxingJuName)}</div><div class="center-small">命宫：${escapeHtml(BRANCHES[chart.mingGongBranch])}　身宫：${escapeHtml(BRANCHES[chart.shenGongBranch])}</div><div class="center-divider"></div><div class="center-small">${escapeHtml(activeForm.date)} ${escapeHtml(activeForm.time)}</div><div class="center-sub">单机离线 · 不联网排盘</div></div>
    </div></div>
    <div class="detail-panel"><h3>${escapeHtml(current.name)} <small>${escapeHtml(STEMS[current.stem])}${escapeHtml(BRANCHES[current.branch])}</small></h3>${detail || '<p>此宫未列出星曜。</p>'}${current.isEmpty?`<div class="detail-foot">空宫借对宫：${escapeHtml(current.borrowedFromName || '')} ${escapeHtml((current.borrowedStars||[]).join('、'))}</div>`:''}</div>
    <div class="sihua-panel"><h3>四化系统</h3><div class="four-block"><div class="four-title">本命四化 · ${escapeHtml(STEMS[chart.lunarInfo.yearStem])}年</div><div class="four-flex">${renderFour(natalMap,'')}</div></div>
    <div class="four-block"><div class="four-title">${activeForm.annualYear} 流年四化 · ${escapeHtml(STEMS[annualStem])}干</div><div class="four-flex">${renderFour(annualMap,'')}</div></div>
    <p class="field-help">流年四化按所选公历年份的年干展示；这里没有实现完整流年命宫或流月、流日盘。公历年初换年口径存在流派差异。</p></div>
    <div class="daxian-panel"><h3>十二大限</h3><div class="daxian-grid">${dxHtml}</div></div>
    <p class="field-help">星曜位置来自上游开源算法；命盘排法随算法版本、流派、出生经度、时辰和闰月选项有所差异。</p>
  </section>`;
  el.querySelectorAll<HTMLButtonElement>('[data-palace]').forEach(btn=>btn.addEventListener('click',()=>{
    selectedBranch = Number(btn.dataset.palace);
    renderChart();
  }));
}
function renderHistory(): void {
  document.querySelector('#history-count')!.textContent = `${history.length} 张已保存`;
  const list = document.querySelector<HTMLElement>('#history-list')!;
  if(!history.length){ list.innerHTML='<div class="empty-history">暂无记录。排好命盘后点击「保存到手机」。</div>';return; }
  list.innerHTML = history.map(h=>`<div class="history-row"><div class="history-info"><b>${escapeHtml(h.form.name||'未命名命盘')}</b><span>${escapeHtml(h.form.date)} ${escapeHtml(h.form.time)} · ${h.form.gender==='male'?'男':'女'}</span></div><div class="history-row-actions"><button data-load="${escapeHtml(h.id)}" class="tertiary">查看</button><button data-remove="${escapeHtml(h.id)}" class="tertiary danger">删除</button></div></div>`).join('');
  list.querySelectorAll<HTMLButtonElement>('[data-load]').forEach(btn=>btn.addEventListener('click',()=>{
    const record = history.find(h=>h.id===btn.dataset.load);
    if(!record) return;
    fillForm(record.form); onGenerate();
    document.querySelector('#chart-output')!.scrollIntoView({behavior:'smooth',block:'start'});
  }));
  list.querySelectorAll<HTMLButtonElement>('[data-remove]').forEach(btn=>btn.addEventListener('click',()=>{
    const record = history.find(h=>h.id===btn.dataset.remove);
    if(!record || !confirm(`确认删除「${record.form.name||record.form.date}」？`))return;
    history = history.filter(h=>h.id!==record.id);
    if(writeHistory()) { renderHistory(); showMessage('已删除这条手机本地记录。'); }
  }));
}
function onGenerate(): void {
  try {
    const form = readForm();
    const result = compute(form);
    activeForm = form; activeChart = result.chart; chartNote = result.note;
    selectedBranch = result.chart.mingGongBranch;
    renderChart();
    (document.querySelector('#save-button') as HTMLButtonElement).disabled = false;
    showMessage('排盘完成。计算由 APK 内的离线引擎执行。');
  } catch (err) {
    console.error('排盘出错:',err);
    showMessage(err instanceof Error ? err.message : '排盘失败，请核对出生信息。', true);
  }
}
function saveActive(): void {
  if(!activeForm||!activeChart)return;
  const id = `${Date.now()}-${Math.random().toString(36).slice(2,10)}`;
  history = [{id,storedAt:Date.now(),form:{...activeForm}},...history].slice(0,200);
  if(writeHistory()) { renderHistory(); showMessage('命盘已保存在本机。建议定期导出 JSON 备份。'); }
}
function exportHistory(): void {
  if(!history.length) {showMessage('没有可以导出的记录。',true);return;}
  const payload = JSON.stringify({app:'onan-ziwei',schema:1,exportedAt:new Date().toISOString(),records:history},null,2);
  const blob = new Blob([payload],{type:'application/json;charset=utf-8'});
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url; anchor.download = `onan-ziwei-backup-${new Date().toISOString().slice(0,10)}.json`;
  document.body.appendChild(anchor); anchor.click(); anchor.remove();
  setTimeout(()=>URL.revokeObjectURL(url),10000);
  showMessage('已请求下载备份文件。请检查手机「下载」目录；如 WebView 不支持下载，可在电脑浏览器的工程预览中导出。');
}
async function importHistory(input: HTMLInputElement): Promise<void> {
  const file = input.files?.[0]; input.value='';
  if(!file)return;
  if(file.size>2_000_000){showMessage('备份文件超过 2MB，请检查是否选错文件。',true);return;}
  try {
    const data=JSON.parse(await file.text());
    if(data.app!=='onan-ziwei' || data.schema!==1 || !Array.isArray(data.records)) throw new Error('不是本应用的有效备份文件。');
    const good: HistoryItem[] = data.records.filter((v:unknown):v is HistoryItem=>{
      if(!v || typeof v!=='object')return false;
      const x=v as HistoryItem;
      return typeof x.id==='string' && typeof x.storedAt==='number' && x.form && typeof x.form.date==='string' && typeof x.form.time==='string' && ['male','female'].includes(x.form.gender);
    });
    if(!good.length) throw new Error('备份文件里没有有效命盘。');
    const byId = new Map([...history,...good].map(v=>[v.id,v]));
    history = [...byId.values()].sort((a,b)=>b.storedAt-a.storedAt).slice(0,200);
    if(writeHistory()){renderHistory();showMessage(`已导入 ${good.length} 张命盘。重复 ID 自动合并。`);}
  }catch(e){showMessage(e instanceof Error?e.message:'备份导入失败。',true);}
}

app.innerHTML = sectionHtml();
(document.querySelector('#birth-form') as HTMLFormElement).addEventListener('submit',e=>{e.preventDefault();onGenerate();});
(document.querySelector('#save-button') as HTMLButtonElement).addEventListener('click',saveActive);
(document.querySelector('#export-btn') as HTMLButtonElement).addEventListener('click',exportHistory);
(document.querySelector('#import-btn') as HTMLButtonElement).addEventListener('click',()=>document.querySelector<HTMLInputElement>('#import-file')!.click());
document.querySelector<HTMLInputElement>('#import-file')!.addEventListener('change',e=>{void importHistory(e.currentTarget as HTMLInputElement);});
renderHistory();
