#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TARGET="$ROOT/vendor/ziwei-doushu"
UPSTREAM="https://github.com/Renhuai123/ziwei-doushu.git"
if [ -d "$TARGET/.git" ]; then
  echo "本地引擎已经存在：$TARGET"
else
  mkdir -p "$ROOT/vendor"
  git clone --depth 1 "$UPSTREAM" "$TARGET"
fi
printf '\n原版排盘引擎来源：%s\n' "$UPSTREAM"
git -C "$TARGET" rev-parse HEAD | tee "$ROOT/vendor-engine-commit.txt"
test -f "$TARGET/lib/ziwei/algorithm.ts"
test -f "$TARGET/lib/ziwei/school-tables.generated.ts"
test -f "$TARGET/LICENSE"
cp "$TARGET/LICENSE" "$ROOT/UPSTREAM-LICENSE.txt"
