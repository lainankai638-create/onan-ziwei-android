# 欧南·紫微斗数 · 安卓离线版（v0.1 工程）

> 状态：**可供联网构建环境编译的 Android 工程源码**，不是已生成或实机验证的 APK。
> 这里提供完整的 UI 源码、离线排盘调用和自动打包流程；在支持联网和 Android SDK 的环境里构建，才会得到 `app-debug.apk`。

## 一、工程实际实现的内容

- 公历出生日期、出生分钟、传统排盘性别、出生地经度、时区、闰月规则和晚子时规则。
- 通过上游 `Renhuai123/ziwei-doushu` 的 **`generateChart()`** 真正计算紫微斗数命盘，**不是随机生成的假命盘**。
- 调用上游的真太阳时计算函数 `calculateTrueSolarTime()`、换日函数 `resolveZiweiDayOffset()`；夏令时通过手动勾选转换。
- 十二宫 4×4 命盘、主辅星、星曜亮度、化禄/权/科/忌以及大限年龄段展示（以当前上游数据可得字段为准）。
- 本命四化、指定公历年份的流年干四化；**未实现完整流年盘以及流月/流日盘**。上游倪师体系当前不展示飞星派的“大限宫干四化”和“宫干自化”。
- 保存个人命盘到应用本地 `localStorage`，读取与删除、本地 JSON 备份导入导出（WebView 下载体验需实机验证）。
- 离线打包：Vite 会把所需排盘算法、依赖以及 UI 编译成静态前端资源；Capacitor 会把这些资源打包进 APK。运行时不配置在线 `server.url`，不接入 AI 在线接口、账号或分析 SDK。

## 二、没有做的内容和注意事项

- 不是原版网站的完整复刻；没有付费版 AI 深度解读、收费功能、账户、50GB 以上的大数据集。
- 这里的“流年四化”是按选择的公历年份取年干，仅显示四化星名；岁首换年口径与完整流年星盘功能仍需继续开发。
- 出生地标准时区默认为中国 UTC+8。海外出生地自行选择标准时区，**不自动识别历史时区和夏令时**。
- 命盘排法因流派和时间口径有差异，需自行对照原版盘例。传统命理不是经科学验证的人生预测。
- 本项目尚未在实际 Android 设备运行测试，不承诺一次构建/安装必然成功。
- 应用数据可能随卸载、清理存储而丢失，请定期导出备份；WebView 是否能直接下载 JSON 请先实机测试。
- GitHub Action 输出的是**调试版 APK**（不是签名发行版，不适合直接分发/上架商店）。

## 三、获取 APK：推荐 GitHub Actions 自动构建（不必在自己的电脑安装 Android Studio）

前提：你有 GitHub 账号、有一次性网络可访问 GitHub/npm/Google 的构建机器，并把**解压后的工程文件**推送到自己创建的 GitHub 仓库。**注意：不能只上传一个 zip 到仓库，仓库里必须有 `.github/workflows/build-apk.yml` 等解压后的文件。**

1. 下载本工程 zip 并解压；在 GitHub 创建一个**私人仓库**，例如 `onan-ziwei-android`，然后把工程目录里全部文件（包含隐藏文件夹 `.github/`）上传/推送到仓库根目录。
2. 打开该仓库的 **Actions** 标签，选择左侧 **构建欧南紫微离线APK**，点击 **Run workflow → Run workflow**。推送到 `main` 后也会自动触发。
3. 构建任务成功后，打开这次任务的 **Artifacts**，下载 `欧南紫微斗数-Android-离线APK` 压缩文件。
4. 解压压缩文件，找到 `app-debug.apk`，发送/下载到安卓手机。打开文件，按照手机提示批准本次安装来源，即可安装。请核对 APK 来源，仅安装自己仓库构建的文件。
5. 打开 APP，用一个你知道结果的盘例先测试 12 宫和主要星曜，确认离线表现。想验离线，把 Wi-Fi 和移动数据都关掉后重新生成命盘。

首次构建时，GitHub Actions **需要联网下载**上游 MIT 代码、npm 依赖和 Android SDK。只有**安装后的运行阶段**设计为无需联网；首次制作 APK 不可能完全不联网。

**GitHub Actions 自动执行内容：**

```bash
npm install --no-audit --no-fund
npm run engine
npm test
npm run build
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
```

APK 路径：`android/app/build/outputs/apk/debug/app-debug.apk`。

## 四、电脑本地构建（可选）

准备 Node.js 22、Git、Android Studio / Android SDK API 35、JDK 21，然后在解压后的工程目录运行：

```bash
npm install
npm run engine
npm test
npm run build
npx cap add android
npx cap sync android
cd android
# Windows PowerShell: .\gradlew.bat assembleDebug
# macOS / Linux:  ./gradlew assembleDebug
```

需要修改界面或排盘规则时，在 `src/main.ts` 和 `src/style.css` 编辑后重新运行 `npm run build` 与 `npx cap sync android`。

## 五、工程目录

```text
.github/workflows/build-apk.yml     GitHub Actions 在线编译 APK
scripts/fetch-engine.sh            下载上游真实排盘引擎，记录 SHA，保留 MIT LICENSE
src/main.ts                        录入、排盘、十二宫、四化、历史命盘、备份
src/style.css                      手机自适应深色 UI
index.html                         静态入口
capacitor.config.ts                Android App 的封装设置
package.json                       依赖与命令
tests/verify-project.mjs           工程结构完整性检查
```

注意：`vendor/ziwei-doushu/` 和 `node_modules/` 不包含在源码压缩包中，需在**构建阶段**用网络获取。运行时不会从仓库拉取算法。

## 六、开源授权和来源

核心算法来自：<https://github.com/Renhuai123/ziwei-doushu>（代码 MIT）。
- `lib/ziwei/algorithm.ts`、`types.ts`、`constants.ts`、`true-solar-time.ts` 均来自原作者，不声称拥有其版权。
- `scripts/fetch-engine.sh` 会把原仓库 `LICENSE` 拷贝成 `UPSTREAM-LICENSE.txt`，保留原始版权许可；构建输出部署时应同时保留授权信息。
- `iztro`：<https://github.com/SylarLong/iztro>
- `lunar-javascript`：<https://github.com/6tail/lunar-javascript>
- `Capacitor`：<https://capacitorjs.com/>

工程本身的新增 UI / 自动化脚本可供个人使用，不包含商业 AI 解读数据、倪师讲课引用语料或大型命盘解读数据集。

## 七、风险与验证状态

- ✅ 已编写 Android 构建工作流、手机适配 UI、原版算法接口对接、历史记录代码。
- ✅ 已执行 `npm test` 的源码结构检查。
- ⏳ 当前制作环境不具备 Android SDK，无法运行 Gradle，也不能联网克隆源仓库。因此 **未编译 `app-debug.apk`、未实际安装验证，不能称为已完成 APK**。
- ⏳ 真正生成 APK 后还需核验：下载备份、时间边界、算法兼容性、华为/小米等机型适配。

