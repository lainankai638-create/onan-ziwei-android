import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.onan.ziwei.offline',
  appName: '欧南·紫微斗数',
  webDir: 'dist',
  // 故意不设置 server.url：打包后的前端资源由 APK 本地提供，非在线网页套壳。
};

export default config;
